:HL["/_next/static/chunks/0dk9a-p1a2rbr.css","style"]
:HL["/_next/static/chunks/0cai4ca--dv~-.css","style"]
:HL["/_next/static/media/83afe278b6a6bb3c-s.p.0q-301v4kxxnr.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}},"staleTime":300,"buildId":"mATRreX5K6C9KP3-zb6cm"}
