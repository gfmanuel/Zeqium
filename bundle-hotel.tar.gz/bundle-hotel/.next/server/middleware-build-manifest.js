globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/vM02jq4xJq8odVe0dKe3N/_buildManifest.js",
    "static/vM02jq4xJq8odVe0dKe3N/_ssgManifest.js",
    "static/vM02jq4xJq8odVe0dKe3N/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0ht900cau6_ur.js",
    "static/chunks/02i7dfk78~t~2.js",
    "static/chunks/00ilazh50sdzh.js",
    "static/chunks/05sqh99f1_wo7.js",
    "static/chunks/turbopack-160nmlc4bk35p.js"
  ]
};
