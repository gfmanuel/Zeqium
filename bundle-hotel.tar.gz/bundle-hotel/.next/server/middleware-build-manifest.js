globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/XP3KMOA0BU-UOdyLNt-Hw/_buildManifest.js",
    "static/XP3KMOA0BU-UOdyLNt-Hw/_ssgManifest.js",
    "static/XP3KMOA0BU-UOdyLNt-Hw/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0ht900cau6_ur.js",
    "static/chunks/02i7dfk78~t~2.js",
    "static/chunks/00ilazh50sdzh.js",
    "static/chunks/05sqh99f1_wo7.js",
    "static/chunks/turbopack-160nmlc4bk35p.js"
  ]
};
