globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/9g3iSt0IwN8kQceDpM7ps/_buildManifest.js",
    "static/9g3iSt0IwN8kQceDpM7ps/_ssgManifest.js",
    "static/9g3iSt0IwN8kQceDpM7ps/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0ht900cau6_ur.js",
    "static/chunks/02i7dfk78~t~2.js",
    "static/chunks/00ilazh50sdzh.js",
    "static/chunks/05sqh99f1_wo7.js",
    "static/chunks/turbopack-160nmlc4bk35p.js"
  ]
};
