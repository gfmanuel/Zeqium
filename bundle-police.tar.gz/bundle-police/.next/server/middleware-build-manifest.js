globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/WQbiC1jCFs66tcPwA7fFz/_buildManifest.js",
    "static/WQbiC1jCFs66tcPwA7fFz/_ssgManifest.js",
    "static/WQbiC1jCFs66tcPwA7fFz/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/15qx7pm65vta4.js",
    "static/chunks/02i7dfk78~t~2.js",
    "static/chunks/04wx0yt85k8sj.js",
    "static/chunks/00ilazh50sdzh.js",
    "static/chunks/turbopack-0f7fj3vvn3l5t.js"
  ]
};
